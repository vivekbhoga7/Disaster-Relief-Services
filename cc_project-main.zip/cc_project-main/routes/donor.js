const express = require("express");
const router = express.Router();
const middleware = require("../middleware/index.js");
const User = require("../models/user.js");
const Donation = require("../models/donation.js");

// Donor Dashboard
router.get("/donor/dashboard", middleware.ensureDonorLoggedIn, async (req, res) => {
    const donorId = req.user._id;
    const numPendingDonations = await Donation.countDocuments({ donor: donorId, status: "pending" });
    const numAcceptedDonations = await Donation.countDocuments({ donor: donorId, status: "accepted" });
    const numAssignedDonations = await Donation.countDocuments({ donor: donorId, status: "assigned" });
    const numCollectedDonations = await Donation.countDocuments({ donor: donorId, status: "collected" });
    res.render("donor/dashboard", {
        title: "Dashboard",
        numPendingDonations,
        numAcceptedDonations,
        numAssignedDonations,
        numCollectedDonations,
    });
});

// Render Donation Form
router.get("/donor/donate", middleware.ensureDonorLoggedIn, (req, res) => {
    res.render("donor/donate", { title: "Donate" });
});

// Handle Donation Submission
router.post("/donor/donate", middleware.ensureDonorLoggedIn, async (req, res) => {
    try {
        const donation = req.body.donation;
        donation.status = "pending";
        donation.donor = req.user._id;

        // Assign type-specific validation logic here
        if (donation.foodType) {
            if (!donation.cookingTime) throw new Error("Cooking time is required for food donations.");
        } else if (donation.clothesType) {
            if (!donation.clothesQuantity) throw new Error("Clothes quantity is required for clothes donations.");
        } else if (donation.medicines) {
            if (!donation.medicineExpiry) throw new Error("Medicine expiry date is required for medicine donations.");
        } else if (donation.amount) {
            if (!donation.paymentMode) throw new Error("Payment mode is required for monetary donations.");
        } else {
            throw new Error("Invalid donation type.");
        }

        const newDonation = new Donation(donation);
        await newDonation.save();

        req.flash("success", "Donation request sent successfully");
        res.redirect("/donor/donations/pending");
    } catch (err) {
        console.error(err);
        req.flash("error", err.message || "Some error occurred on the server.");
        res.redirect("back");
    }
});

// View Pending Donations
router.get("/donor/donations/pending", middleware.ensureDonorLoggedIn, async (req, res) => {
    try {
        const pendingDonations = await Donation.find({
            donor: req.user._id,
            status: { $in: ["pending", "rejected", "accepted", "assigned"] },
        }).populate("agent");
        res.render("donor/pendingDonations", { title: "Pending Donations", pendingDonations });
    } catch (err) {
        console.error(err);
        req.flash("error", "Some error occurred on the server.");
        res.redirect("back");
    }
});

// View Previous Donations
router.get("/donor/donations/previous", middleware.ensureDonorLoggedIn, async (req, res) => {
    try {
        const previousDonations = await Donation.find({ donor: req.user._id, status: "collected" }).populate("agent");
        res.render("donor/previousDonations", { title: "Previous Donations", previousDonations });
    } catch (err) {
        console.error(err);
        req.flash("error", "Some error occurred on the server.");
        res.redirect("back");
    }
});

// Delete Rejected Donation
router.get("/donor/donation/deleteRejected/:donationId", async (req, res) => {
    try {
        const donationId = req.params.donationId;
        await Donation.findByIdAndDelete(donationId);
        req.flash("success", "Rejected donation deleted successfully.");
        res.redirect("/donor/donations/pending");
    } catch (err) {
        console.error(err);
        req.flash("error", "Some error occurred on the server.");
        res.redirect("back");
    }
});

// View Donor Profile
router.get("/donor/profile", middleware.ensureDonorLoggedIn, (req, res) => {
    res.render("donor/profile", { title: "My Profile" });
});

// Update Donor Profile
router.put("/donor/profile", middleware.ensureDonorLoggedIn, async (req, res) => {
    try {
        const id = req.user._id;
        const updateObj = req.body.donor; // Example: {firstName, lastName, gender, address, phone}
        await User.findByIdAndUpdate(id, updateObj);

        req.flash("success", "Profile updated successfully");
        res.redirect("/donor/profile");
    } catch (err) {
        console.error(err);
        req.flash("error", "Some error occurred on the server.");
        res.redirect("back");
    }
});

module.exports = router;
